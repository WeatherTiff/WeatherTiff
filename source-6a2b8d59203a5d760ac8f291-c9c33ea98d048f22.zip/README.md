# WeatherTiff

A clean, atmospheric weather dashboard for tracking conditions across multiple locations. Modeled after the original app at [weather-tiff.vercel.app](https://weather-tiff.vercel.app/).

## Technologies

- Pure HTML, CSS, and vanilla JavaScript — no build step, no framework
- Google Fonts (Playfair Display, Syne, JetBrains Mono)
- `localStorage` for persisting tracked locations between sessions

## Running Locally

Open `index.html` directly in a browser, or serve it with any static file server:

```bash
npx serve .
# or
python3 -m http.server
```

## Features

- Add and remove city weather cards
- Toggle between °F and °C
- Autocomplete city search from a built-in list
- Persists your locations across page reloads
- Atmospheric animated background with glassmorphism card design
