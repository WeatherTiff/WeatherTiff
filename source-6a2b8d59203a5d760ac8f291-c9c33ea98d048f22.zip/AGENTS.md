# AGENTS.md — WeatherTiff

## Overview

WeatherTiff is a static single-page weather tracker. The entire application lives in one file: `index.html`. There is no build system, framework, or backend.

## Key Directories

```
/
├── index.html       # Entire application (HTML + CSS + JS)
└── README.md        # User-facing documentation
```

## Architecture

All logic is inline in `index.html`:

- **CSS** — Custom properties (`:root` variables), no preprocessor. Glassmorphism cards, CSS `clip-path` for chamfered button corners, `backdrop-filter` for blur effects.
- **JS** — Vanilla ES6+. State is two variables: `unit` (string) and `locations` (array). Persisted to `localStorage` under the key `wtLocations`.
- **Mock data** — `CITY_SUGGESTIONS` array provides 15 preset US cities with realistic weather values. `WEATHER_CONDITIONS` maps condition types to SVG icons and glow colors.

## Coding Conventions

- No external JS dependencies — all icons are inline SVGs.
- Temperature stored as °F internally; `displayTemp()` converts on render.
- `renderCards()` always does a full re-render of the grid (no virtual DOM, list is small).
- `saveAndRender()` = write to `localStorage` + re-render.

## Non-obvious Decisions

- `conditionIdx` on each location is assigned randomly at add-time, since there's no real weather API. This gives visual variety across cards.
- `clip-path: polygon(...)` on buttons/modal creates the chamfered-corner aesthetic without extra DOM elements.
- The grain overlay uses a fixed SVG `feTurbulence` filter via a `data:` URI on a `position: fixed` element so it never scrolls and never triggers layout.
- Suggestions dropdown auto-hides on item click by setting `cityInput._selected` as a side-channel reference; the actual add uses this to skip string parsing.
